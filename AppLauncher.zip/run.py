import sys
import os

if getattr(sys, "frozen", False):
    # Onefile PyInstaller build - anchor on the exe itself, not this
    # script's temp extraction path (same BASE_DIR fix used in
    # AppLauncher.py, needed here too since this is what PyInstaller
    # actually builds AppLauncher.exe from).
    BASE_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)
sys.path.insert(0, BASE_DIR)


def _known_desktop_paths():
    # Several ways to ask Windows "where is Desktop", tried in order of
    # reliability, because any single one of these can be wrong on a given
    # PC (most commonly: OneDrive's "Known Folder Move" redirects Desktop
    # to somewhere under the OneDrive folder, and not every lookup method
    # reflects that redirection). Every candidate that resolves is kept and
    # checked against, instead of trusting just the first one - a false
    # "you're not on your Desktop" is worse than being a little permissive.
    candidates = []
    try:
        import winreg
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders",
        ) as key:
            value, _ = winreg.QueryValueEx(key, "Desktop")
            value = os.path.expandvars(value)
            if value:
                candidates.append(value)
    except Exception:
        pass
    try:
        import ctypes
        import ctypes.wintypes as wintypes
        CSIDL_DESKTOPDIRECTORY = 0x0010
        buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
        ctypes.windll.shell32.SHGetFolderPathW(0, CSIDL_DESKTOPDIRECTORY, 0, 0, buf)
        if buf.value:
            candidates.append(buf.value)
    except Exception:
        pass
    candidates.append(os.path.join(os.path.expanduser("~"), "Desktop"))
    seen = set()
    out = []
    for c in candidates:
        norm = os.path.normcase(os.path.normpath(c))
        if norm not in seen:
            seen.add(norm)
            out.append(norm)
    return out


def _require_desktop_for_distributed_copies():
    # A ".git" folder alongside this one means it's Ash's own working copy
    # of the source (the repo he edits and pushes from) - that's never
    # zipped up and sent to anyone, so it's exempt no matter where it
    # lives. Anyone else's copy came from the distributed zip, which never
    # includes ".git", and is required to sit directly on their Desktop so
    # it's easy to find and support instead of getting buried in Downloads
    # or duplicated across random folders.
    if os.path.isdir(os.path.join(BASE_DIR, ".git")):
        return
    # Manual escape hatch: if the automatic Desktop detection is ever wrong
    # for someone's particular PC setup, creating an empty file named
    # ".desktop_override" in this folder skips the check entirely - no new
    # build needed to unblock someone while a real fix is worked out.
    if os.path.isfile(os.path.join(BASE_DIR, ".desktop_override")):
        return
    desktops = _known_desktop_paths()
    base = os.path.normcase(os.path.normpath(BASE_DIR))
    parent = os.path.normcase(os.path.normpath(os.path.dirname(BASE_DIR)))
    # Counts as "on the Desktop" whether this folder sits one level under
    # Desktop (Desktop\App Launcher\..., the normal case after extracting
    # the zip into its own folder) OR its files were extracted loose
    # directly onto the Desktop with no subfolder at all (parent == base's
    # own parent in that case, so check base itself too).
    if parent in desktops or base in desktops:
        return
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        detected = desktops[0] if desktops else "(couldn't detect your Desktop folder)"
        messagebox.showerror(
            "App Launcher",
            "App Launcher needs to run from a folder on your Desktop.\n\n"
            "Move this whole folder onto your Desktop, then open it from there.\n\n"
            "If this folder really is already on your Desktop, something about "
            "this PC's setup (like OneDrive) may be confusing the check - screenshot "
            "this and send it over so it can get fixed.\n\n"
            f"This folder:\n{BASE_DIR}\n\n"
            f"Detected Desktop:\n{detected}",
        )
        root.destroy()
    except Exception:
        pass
    sys.exit(1)


def _lock_down_distributed_copy():
    # Mark the app's own source/launcher files read-only so friends can't
    # casually edit them (by accident or otherwise) in a text editor. This
    # is a courtesy/tamper deterrent, not a security boundary - nothing
    # that actually matters (like who gets Owner powers) trusts the client;
    # the server independently verifies all of that regardless of what a
    # local file says. Runs on every launch (cheap, idempotent) so it keeps
    # working even if a file was somehow re-created writable. Only applies
    # to distributed copies (no ".git" folder) - never Ash's own working
    # copy of the source. Keep this list in sync with AppLauncher.py's
    # UPDATE_FILES - the in-app updater already knows how to temporarily
    # clear this flag to apply new versions, so it isn't locked out by it.
    if os.path.isdir(os.path.join(BASE_DIR, ".git")):
        return
    import stat
    protect = [
        "AppLauncher.py", "AppContacts.py", "AppNet.py", "AppBrowser.py",
        "AppFriends.py", "AppGames.py", "run.py", "VERSION",
        "App Launcher.vbs", "App Launcher.bat", "Start Here.vbs", "Install and Run.bat",
    ]
    for name in protect:
        path = os.path.join(BASE_DIR, name)
        try:
            if os.path.isfile(path):
                os.chmod(path, stat.S_IREAD)
        except Exception:
            pass


_require_desktop_for_distributed_copies()
_lock_down_distributed_copy()

try:
    import ctypes
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

from AppLauncher import AppLauncher
app = AppLauncher()
app.lift()
app.focus_force()
app.mainloop()
