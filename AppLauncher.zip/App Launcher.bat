@echo off
cd /d "%~dp0"

set "USE_EXE=0"
if exist "%~dp0AppLauncher.exe" (
    set "USE_EXE=1"
    if exist "%~dp0AppLauncher.py" (
        rem If the .py source is newer than the built .exe, the .exe is
        rem stale - fall back to running the source instead of old code.
        for /f %%i in ('powershell -NoProfile -Command "if ((Get-Item '%~dp0AppLauncher.py').LastWriteTime -gt (Get-Item '%~dp0AppLauncher.exe').LastWriteTime) { 'stale' }"') do set "USE_EXE=0"
    )
)

if "%USE_EXE%"=="1" (
    start "" "%~dp0AppLauncher.exe"
    goto :eof
)

where pythonw >nul 2>nul
if %errorlevel%==0 (
    start "" pythonw "%~dp0run.py"
    goto :eof
)
where pyw >nul 2>nul
if %errorlevel%==0 (
    start "" pyw "%~dp0run.py"
    goto :eof
)
echo Couldn't find Python (pythonw/pyw) on your PATH.
echo Install Python from https://www.python.org/downloads/ and make sure
echo "Add python.exe to PATH" is checked during setup, then try again.
pause
