@echo off
cd /d "%~dp0"
echo ===================================================
echo  Pushing your changes to GitHub
echo  This is what makes the server (Render) and everyone's
echo  "Update available" notice actually pick up new fixes -
echo  nothing changes for anyone until this step runs.
echo ===================================================
echo.

where git >nul 2>nul
if not %errorlevel%==0 (
    echo Couldn't find git on your PATH.
    echo Install it from https://git-scm.com/download/win, then run this again.
    pause
    exit /b 1
)

git add -A
git commit -m "Update App Launcher"
if not %errorlevel%==0 (
    echo.
    echo (Nothing new to commit, or the commit step had nothing to do -
    echo  that's fine if you already pushed everything.)
)

echo.
echo Pushing to GitHub...
git push
if not %errorlevel%==0 (
    echo.
    echo Push failed - see the errors above. If it asked you to sign in,
    echo follow the prompts in the window/browser that opened, then run
    echo this file again.
    pause
    exit /b 1
)

echo.
echo ===================================================
echo  Done! Render usually picks this up within a minute
echo  or two. Sign out and back in to App Launcher after
echo  that to pick up the fix.
echo ===================================================
pause
